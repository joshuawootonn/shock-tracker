const axios = require("axios");

// USER

// get

// axios.get('http://localhost:3000/api/session/22')
// .then(function (response) {
//   console.log(response);
// })
// .catch(function (error) {
//   console.log(error);
// });


// get by location

// axios.get('http://localhost:3000/api/session/byLocation/-91.6633/41.7069/8')
//   .then(function (response) {
//     console.log(response);
//   })
//   .catch(function (error) {
//     console.log(error);
//   });

// get all

// axios.get('http://localhost:3000/api/sessions')
//   .then(function (response) {
//     console.log(response);
//   })
//   .catch(function (error) {
//     console.log(error);
//   });

//post

// axios
//   .post("http://iot4-env-1.us-east-1.elasticbeanstalk.com/api/session", {     
//     start_time: "now()",
//     end_time: "now()",
//     data: [
//       {
//         timestamp: "now()",
//         gyro: {
//           pitch: "1",
//           yaw: "1",
//           roll: "1"
//         },
//         gps: {
//           longitude: "2",
//           latitude: "2"
//         },
//         accel: {
//           x: "3",
//           y: "3",
//           z: "3"
//         }
//       },
//       {
//         timestamp: "now()",
//         gyro: {
//           pitch: "1",
//           yaw: "1",
//           roll: "1"
//         },
//         gps: {
//           longitude: "2",
//           latitude: "2"
//         },
//         accel: {
//           x: "3",
//           y: "3",
//           z: "3"
//         }
//       }
//     ]
//   })
//   .then(function(response) {
//     console.log(response);
//   })
//   .catch(function(error) {
//     console.log(error);
//   });

//delete

// axios.delete('http://localhost:3000/api/session/22')
//     .then(function (response) {
//       console.log(response);
//     })
//     .catch(function (error) {
//       console.log(error);
//     });
