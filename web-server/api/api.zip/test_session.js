const axios = require("axios");

// USER

// get all

// axios.get('http://localhost:3000/api/sessions')
//   .then(function (response) {
//     console.log(response);
//   })
//   .catch(function (error) {
//     console.log(error);
//   });

// get by user

// axios.get('http://localhost:3000/api/session/byUser/1')
//   .then(function (response) {
//     console.log(response);
//   })
//   .catch(function (error) {
//     console.log(error);
//   });

// get

// axios.get('http://localhost:3000/api/session/22')
// .then(function (response) {
//   console.log(response);
// })
// .catch(function (error) {
//   console.log(error);
// });

//post

// axios
//   .post("http://localhost:3000/api/session", {
//     user_id: "2",
//     start_time: "now()",
//     end_time: "now()",
//     data: [
//       {
//         timestamp: "now()",
//         gyro: {
//           pitch: "1",
//           yaw: "1",
//           roll: "1"
//         },
//         gps: {
//           longitude: "2",
//           latitude: "2"
//         },
//         accel: {
//           x: "3",
//           y: "3",
//           z: "3"
//         }
//       },
//       {
//         timestamp: "now()",
//         gyro: {
//           pitch: "1",
//           yaw: "1",
//           roll: "1"
//         },
//         gps: {
//           longitude: "2",
//           latitude: "2"
//         },
//         accel: {
//           x: "3",
//           y: "3",
//           z: "3"
//         }
//       }
//     ]
//   })
//   .then(function(response) {
//     console.log(response);
//   })
//   .catch(function(error) {
//     console.log(error);
//   });

//delete

// axios.delete('http://localhost:3000/api/session/22')
//     .then(function (response) {
//       console.log(response);
//     })
//     .catch(function (error) {
//       console.log(error);
//     });
