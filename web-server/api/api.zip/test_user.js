const axios = require('axios');

// USER

// get all 

// axios.get('http://localhost:3000/api/users')
//   .then(function (response) {
//     console.log(response);
//   })
//   .catch(function (error) {
//     console.log(error);
//   });

// get 

// axios.get('http://localhost:3000/api/user/1')
// .then(function (response) {
//   console.log(response);
// })
// .catch(function (error) {
//   console.log(error);
// });

//post

// axios.post('http://localhost:3000/api/user', {
//       user_name: 'josh wootonn',
//       uuid: '23412341234123' // This should be taken from the user creation response from aws or firbase
//     })
//     .then(function (response) {
//       console.log(response);
//     })
//     .catch(function (error) {
//       console.log(error);
//     });

//put

// axios.put('http://localhost:3000/api/user/3', {
//       user_name: 'josh wootonn2'// just the params you want to update     
//     })
//     .then(function (response) {
//       console.log(response);
//     })
//     .catch(function (error) {
//       console.log(error);
//     });

//delete

// axios.delete('http://localhost:3000/api/user/3')
//     .then(function (response) {
//       console.log(response);
//     })
//     .catch(function (error) {
//       console.log(error);
//     });
